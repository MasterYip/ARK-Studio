# Contract Fixture

This is an ARK Studio project folder. Open it from the workbench's project switcher, or run `python -m arkstudio serve --root <parent-folder>`.

- `project.json` — identity and display metadata
- `ark.sqlite3` — units, tags, links, media references, activity
- `assets/` — local media (optional)
- `exports/` — generated exports
- `logs/activity.jsonl` — append-only activity mirror

Copy the whole folder to back up or move the project.
